
<?php $__env->startSection('admin_content'); ?>
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-danger text-white">
        <div class="card-header">
          <span class="h5"><?php echo e($title); ?></span>
        </div>
        <div class="card-body bg-white text-dark">
          <?php if($errors->any()): ?>
            <div class="text-center font-weight-bold text-danger mb-3">
              <?php echo implode(', ',$errors->all()); ?>

            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('admin.group.edit',['uuid'=>$data->uuid])); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Nama Grup</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="Masukkan nama grup" value="<?php echo e(old('name')??$data->name); ?>">
            </div>
            <div class="form-group">
              <label for="description">Deskripsi</label>
              <textarea name="description" rows="4" class="form-control" placeholder="Masukkan deskripsi grup"><?php echo e(old('description')??$data->description); ?></textarea>
            </div>
            <button type="submit" class="btn btn-danger">Simpan</button>
            <a href="<?php echo e(route('admin.group.index')); ?>" name="description" class="btn btn-dark">Batal</a>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/admin/group/edit.blade.php ENDPATH**/ ?>