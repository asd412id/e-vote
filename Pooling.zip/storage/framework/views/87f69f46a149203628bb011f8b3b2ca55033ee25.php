
<h1 class="text-center pt-5">Selamat Datang</h1>
<h4 class="text-center"><?php echo e(auth()->user()->name); ?></h4>

<div class="col-md-4 offset-md-4 col-12 mt-3">
  <?php if($errors->any()): ?>
    <div class="font-weight-bold text-danger text-center p-0 mb-0 mb-3"><?php echo implode('<br>',$errors->all()); ?></div>
  <?php endif; ?>
  <div class="card card-body">
    <?php if(count($subject)): ?>
      <div class="text-center h5">Klik pilihan di bawah untuk mulai melakukan voting online</div>

      <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('vote.voting',['uuid'=>$s->uuid])); ?>" class="d-block btn btn-lg btn-danger mt-2">
          <?php echo e($s->name); ?>

        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <div class="text-center h5">Tidak ada subject voting saat ini</div>
    <?php endif; ?>
  </div>
  <div class="text-center my-3">
    <a href="<?php echo e(route('logout')); ?>" class="btn btn-secondary confirm" data-text="Yakin ingin keluar? Pastikan Anda sudah melakukan voting">Keluar</a>
  </div>
</div>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/vote/index.blade.php ENDPATH**/ ?>