
<h4 class="text-center pt-3">Selamat Datang</h4>
<h5 class="text-center"><?php echo e(auth()->user()->name); ?></h5>
<?php if($errors->any()): ?>
  <div class="font-weight-bold text-danger text-center p-0 mb-0 mb-3"><?php echo implode('<br>',$errors->all()); ?></div>
<?php endif; ?>
<div class="col-md-8 offset-md-2 col-12 mt-3" id="voting">
  <div class="text-center h1"><?php echo e($subject->name); ?></div>
  <?php if(count($subject->candidates) && !$subject->voters->where('id',auth()->user()->id)->first()): ?>
    <div class="h4 text-center mb-3"><?php echo e($subject->description??'Yang mana yang Anda pilih?'); ?></div>
    <form action="" method="post" id="fchoice">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="choice" id="choice">
      <?php $__currentLoopData = $subject->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-<?php echo e(12/count($subject->candidates)); ?> col-12 mb-3 float-left">
          <div class="card candidate" id="<?php echo e($c->uuid); ?>">
            <div class="card-body">
              <img src="<?php echo e(\Storage::disk('public')->url(@$c->opt['photo'])); ?>" alt="" class="photo">
            </div>
            <div class="card-footer text-center font-weight-bold h5">
              <?php echo e($c->name); ?>

            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="clearfix"></div>
      <div class="text-center">
        <button type="submit" class="btn btn-lg btn-danger" disabled>SIMPAN PILIHAN</button>
      </div>
    </form>
  <?php else: ?>
    <?php
      $vote = auth()->user()->vote->where('subject_id',$subject->id)->first();
    ?>
    <div class="h4 text-center mb-3">Terima Kasih telah Berpartisipasi dalam Pemungutan Suara <?php echo e($subject->name); ?></div>
    <div class="h4 text-center mb-3 text-danger">Anda telah melakukan pemungutan suara pada hari <?php echo e($vote->created_at->locale('id')->translatedFormat('l, j F Y')); ?> pukul <?php echo e($vote->created_at->format('H:i')); ?></div>
    <h2 class="text-center mb-3">Jumlah Suara yang Masuk: <?php echo e($subject->progress()); ?>%</h2>

    <?php $__currentLoopData = $subject->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-<?php echo e(12/count($subject->candidates)); ?> col-12 mb-3 float-left">
        <div class="card">
          <div class="card-body text-center h4"><?php echo e($subject->candidateProgress($c->id)); ?>%</div>
          <div class="card-footer text-center h5"><?php echo e($c->name); ?></div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  <div class="text-center my-3">
    <a href="<?php echo e(route('vote.index')); ?>" class="btn btn-lg btn-dark">KEMBALI</a>
  </div>
</div>
<?php $__env->startSection('foot'); ?>
  <script>
    setTimeout(()=>{
      location.reload();
    },60000)
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/vote/voting.blade.php ENDPATH**/ ?>