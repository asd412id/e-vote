
<?php $__env->startSection('admin_content'); ?>
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-danger text-white">
        <div class="card-header">
          <span class="h5"><?php echo e($title); ?></span>
        </div>
        <div class="card-body bg-white text-dark">
          <?php if($errors->any()): ?>
            <div class="text-center font-weight-bold text-danger mb-3">
              <?php echo implode(', ',$errors->all()); ?>

            </div>
          <?php endif; ?>
          <form method="post" action="<?php echo e(route('admin.user.update',['uuid'=>$data->uuid])); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Nama</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="Masukkan Nama Lengkap" value="<?php echo e(old('name')??$data->name); ?>">
            </div>
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" name="username" id="username" placeholder="Masukkan Username" value="<?php echo e(old('username')??$data->username); ?>">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" name="password" id="password" placeholder="Kosongkan jikat tidak ingin mengubah" value="">
            </div>
            <div class="form-group">
              <label for="group">Grup</label>
              <select class="form-control" name="group" id="group">
                <option  value="">Pilih Grup</option>
                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option <?php echo e((old('group')==$v->id || $data->group_id==$v->id)?'selected':''); ?> value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="role">Role</label>
              <select class="form-control" name="role" id="role">
                <option <?php echo e((old('role')=='guest' || $data->role=='guest')?'selected':''); ?> value="guest">Guest</option>
                <option <?php echo e((old('role')=='admin' || $data->role=='admin')?'selected':''); ?> value="admin">Admin</option>
              </select>
            </div>
            <button type="submit" class="btn btn-danger">Simpan</button>
            <a href="<?php echo e(route('admin.user.index')); ?>" name="description" class="btn btn-dark">Batal</a>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>