
<h3 class="text-center pt-5">Selamat Datang</h3>
<h5 class="text-center">Silahkan Login untuk Melanjutkan</h5>

<div class="col-md-4 offset-md-4 col-12">
  <?php if($errors->any()): ?>
    <div class="font-weight-bold text-danger text-center p-0 mb-0 mt-4"><?php echo implode('<br>',$errors->all()); ?></div>
  <?php endif; ?>
  <form method="post">
    <?php echo csrf_field(); ?>
    <?php if(request()->redirect): ?>
      <input type="hidden" name="redirect" value="<?php echo e(request()->redirect); ?>">
    <?php endif; ?>
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" class="form-control" name="username" id="username" placeholder="Masukkan Username" required autofocus>
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" class="form-control" name="password" id="password" placeholder="Masukkan Password" required>
    </div>
    <button type="submit" class="btn btn-success">Login</button>
  </form>
</div>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/login.blade.php ENDPATH**/ ?>