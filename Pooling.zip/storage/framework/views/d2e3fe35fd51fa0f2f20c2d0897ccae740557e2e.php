
<?php $__env->startSection('admin_content'); ?>
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-danger text-white">
        <div class="card-header">
          <span class="h5"><?php echo e($title); ?></span>
        </div>
        <div class="card-body bg-white text-dark">
          <?php if($errors->any()): ?>
            <div class="text-center font-weight-bold text-danger mb-3">
              <?php echo implode(', ',$errors->all()); ?>

            </div>
          <?php endif; ?>
          <form method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Nama Subject</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="Masukkan nama subject" value="<?php echo e(old('name')); ?>">
            </div>
            <div class="form-group">
              <label for="description">Deskripsi</label>
              <textarea name="description" rows="4" class="form-control" placeholder="Masukkan deskripsi subject"><?php echo e(old('description')); ?></textarea>
            </div>
            <div class="form-group">
              <label for="time">Waktu Voting</label>
              <input type="text" class="form-control datepicker" name="time" id="time" placeholder="Masukkan masuk voting" value="<?php echo e(old('time')); ?>">
            </div>
            <div class="form-group">
              <label for="status">Status</label>
              <select class="form-control" name="status" id="status">
                <option <?php echo e(old('status')=='1'?'selected':''); ?> value="1">Aktif</option>
                <option <?php echo e(old('status')=='0'?'selected':''); ?> value="0">Tidak Aktif</option>
              </select>
            </div>
            <div class="form-group">
              <label for="participants">Partisipan</label>
              <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" name="participants[]" value="<?php echo e($g->id); ?>" class="custom-control-input" id="<?php echo e($g->uuid); ?>">
                  <label class="custom-control-label" for="<?php echo e($g->uuid); ?>"><?php echo e($g->name); ?></label>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button type="submit" class="btn btn-danger">Simpan</button>
            <a href="<?php echo e(route('admin.subject.index')); ?>" name="description" class="btn btn-dark">Batal</a>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/admin/subject/create.blade.php ENDPATH**/ ?>