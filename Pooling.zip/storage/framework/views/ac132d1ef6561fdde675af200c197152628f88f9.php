
<?php $__env->startSection('admin_content'); ?>
  <div class="card bg-danger text-light">
    <div class="card-header">
      <span class="h5"><?php echo e($title); ?></span>
      <a href="<?php echo e(route('admin.subject.index')); ?>" class="btn btn-sm btn-light text-danger float-right"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
    <div class="card-body bg-white text-dark">
      <h2 class="text-center mb-3">Jumlah Suara yang Masuk: <?php echo e($subject->progress()); ?>%</h2>

      <?php $__currentLoopData = $subject->candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-<?php echo e(12/count($subject->candidates)); ?> col-12 mb-3 float-left">
          <div class="card">
            <div class="card-body text-center h4"><?php echo e($subject->candidateProgress($c->id)); ?>%</div>
            <div class="card-footer text-center h5"><?php echo e($c->name); ?></div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
  <script>
    setTimeout(()=>{
      location.reload();
    },60000)
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/admin/subject/show.blade.php ENDPATH**/ ?>