
<?php $__env->startSection('admin_content'); ?>
  <div class="card bg-danger text-light">
    <div class="card-header">
      <span class="h5"><?php echo e($title); ?></span>
      <a href="<?php echo e(route('admin.subject.create')); ?>" class="btn btn-sm btn-light text-danger float-right"><i class="fa fa-plus"></i> Tambah Data</a>
    </div>
    <div class="card-body bg-white text-black">
      <?php if(session()->has('message')): ?>
        <div class="font-weight-bold text-success mb-3">
          <?php echo e(session()->get('message')); ?>

        </div>
      <?php endif; ?>
      <table class="table table-hover table-striped">
        <thead class="bg-danger text-light">
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Deskripsi</th>
            <th>Mulai</th>
            <th>Selesai</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($data)): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="text-center"><?php echo e(($data->firstItem()+$key).'.'); ?></td>
                <td width="30%"><?php echo e($v->name??'-'); ?></td>
                <td width="30%"><?php echo e($v->description??'-'); ?></td>
                <td width="20%"><?php echo e($v->start->locale('id')->translatedFormat('d/m/Y H:i')); ?></td>
                <td width="20%"><?php echo e($v->end->locale('id')->translatedFormat('d/m/Y H:i')); ?></td>
                <td width="20%"><?php echo $v->status?'<span class="badge badge-success">Aktif</span>':'<span class="badge badge-danger">Tidak Aktif</span>'; ?></td>
                <td>
                  <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                    <a href="<?php echo e(route('admin.subject.show',['uuid'=>$v->uuid])); ?>" class="btn btn-info" title="Detail"><i class="fa fa-info-circle"></i></a>
                    <a href="<?php echo e(route('admin.candidate.index',['subject_uuid'=>$v->uuid])); ?>" class="btn btn-warning" title="Participants"><i class="fa fa-users"></i></a>
                    <a href="<?php echo e(route('admin.subject.edit',['uuid'=>$v->uuid])); ?>" class="btn btn-info" title="Edit"><i class="fa fa-edit"></i></a>
                    <a href="<?php echo e(route('admin.subject.destroy',['uuid'=>$v->uuid])); ?>" class="btn btn-danger confirm" title="Hapus" data-text="Yakin ingin menghapus?"><i class="fa fa-trash"></i></a>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <tr>
              <td colspan="7" class="text-center text-danger font-weight-bold">Data tidak tersedia</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
      <?php if($data->hasPages()): ?>
        <div class="text-right">
          <div class="d-inline-block">
            <?php echo $data->links(); ?>

          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\web\Pooling\resources\views/admin/subject/index.blade.php ENDPATH**/ ?>