<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/fontawesome/css/all.min.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.min.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>" charset="utf-8"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/bootstrap.min.js')); ?>" charset="utf-8"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>" charset="utf-8"></script>
    <?php echo $__env->yieldContent('foot'); ?>
  </body>
</html>
<?php /**PATH D:\PROJECTS\web\Pooling\resources\views/layout.blade.php ENDPATH**/ ?>